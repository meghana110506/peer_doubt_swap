let currentStars = parseInt(sessionStorage.getItem('pds_stars') || '0');

function updateEmptyState() {
  const commentList = document.getElementById('comment-list');
  let emptyMsg = document.getElementById('empty-msg');
  if (commentList && commentList.children.length === 0) {
    if (!emptyMsg) {
      emptyMsg = document.createElement('p');
      emptyMsg.id = 'empty-msg';
      emptyMsg.className = 'empty-msg';
      emptyMsg.innerText = 'Still looking for solutions... be the first to answer!';
      commentList.parentNode.appendChild(emptyMsg);
    }
  } else if (emptyMsg) {
    emptyMsg.remove();
  }
}

async function addComment() {
  const commentInput = document.getElementById('new-comment');
  const commentList = document.getElementById('comment-list');
  const doubtId = sessionStorage.getItem('pds_currentDoubtId');
  const answerText = commentInput.value.trim();

  if (!answerText) { alert('Please write something before posting.'); return; }

  const username = sessionStorage.getItem('pds_username') || 'anonymous';

  // Save answer to backend API
  try {
    const res = await fetch(API_BASE + `/doubts/${doubtId}/comments`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ answer_text: answerText })
    });

    if (!res.ok) {
      const data = await res.json();
      alert('Error: ' + (data.error || 'Failed to post comment.'));
      return;
    }
    
    // Refresh user profile in background to update stars
    fetch(API_BASE + '/profile', { headers: getAuthHeaders() }).then(r => r.json()).then(user => {
      saveAuth(getToken(), user);
      const starEl = document.getElementById('star-count');
      if (starEl) starEl.innerText = user.stars;
    });

  } catch (err) {
    console.error('Error posting comment:', err);
    alert('Could not connect to server.');
    return;
  }

// Add to comment list in UI
  const li = document.createElement('li');
  li.className = 'comment-item';
  li.innerHTML = `<strong>@${username}</strong>: ${answerText}`;
  commentList.appendChild(li);
  commentInput.value = '';

  const emptyMsg = document.getElementById('empty-msg');
  if (emptyMsg) emptyMsg.remove();
}

window.onload = function () {
  const doubtId = sessionStorage.getItem('pds_currentDoubtId');
  if (!doubtId) {
    alert('No doubt selected.');
    window.location.href = 'doubtSolver1.html';
    return;
  }

  const user = getUser();
  const starEl = document.getElementById('star-count');
  if (starEl && user) starEl.innerText = user.stars || 0;

  fetchDoubtDetails(doubtId);
};

async function fetchDoubtDetails(doubtId) {
  try {
    // 1. Fetch doubt details
    const doubtRes = await fetch(API_BASE + `/doubts/${doubtId}`);
    if (doubtRes.ok) {
      const doubt = await doubtRes.json();
      
      const qEl = document.getElementById('display-question');
      if (qEl) qEl.innerText = doubt.question;

      const subjEl = document.getElementById('meta-subject');
      if (subjEl) subjEl.innerText = '📚 ' + (doubt.subject || doubt.subjectName || '');

      const diffEl = document.getElementById('meta-difficulty');
      if (diffEl) diffEl.innerText = '⚡ ' + doubt.difficulty;
    }

    // 2. Fetch comments for this doubt
    const commentsRes = await fetch(API_BASE + `/doubts/${doubtId}/comments`);
    if (commentsRes.ok) {
      const comments = await commentsRes.json();
      const commentList = document.getElementById('comment-list');
      commentList.innerHTML = ''; // Clear loading text

      if (comments.length === 0) {
        let emptyMsg = document.createElement('p');
        emptyMsg.id = 'empty-msg';
        emptyMsg.className = 'empty-msg';
        emptyMsg.innerText = 'Still looking for solutions... be the first to answer!';
        commentList.parentNode.appendChild(emptyMsg);
      } else {
        const emptyMsg = document.getElementById('empty-msg');
        if (emptyMsg) emptyMsg.remove();

        comments.forEach(c => {
          const li = document.createElement('li');
          li.className = 'comment-item';
          li.innerHTML = `<strong>@${c.solver_username}</strong>: ${c.answer_text}`;
          commentList.appendChild(li);
        });
      }
    }
  } catch (err) {
    console.error('Error fetching doubt details:', err);
  }
}
