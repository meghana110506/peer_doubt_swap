/**
 * api.js — Shared API helper for all frontend pages
 * Provides the base URL and auth header for fetch calls.
 */
const API_BASE = 'http://localhost:3000/api';

function getAuthHeaders() {
  const token = localStorage.getItem('pds_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': 'Bearer ' + token } : {})
  };
}

function getToken() {
  return localStorage.getItem('pds_token');
}

function getUser() {
  const raw = localStorage.getItem('pds_user');
  return raw ? JSON.parse(raw) : null;
}

function saveAuth(token, user) {
  localStorage.setItem('pds_token', token);
  localStorage.setItem('pds_user', JSON.stringify(user));
}

function clearAuth() {
  localStorage.removeItem('pds_token');
  localStorage.removeItem('pds_user');
}

function isLoggedIn() {
  return !!localStorage.getItem('pds_token');
}
