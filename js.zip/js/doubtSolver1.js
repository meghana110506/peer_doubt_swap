window.onload = function () {
  const stars = sessionStorage.getItem('pds_stars') || '0';
  const starEl = document.getElementById('star-count');
  if (starEl) starEl.innerText = stars;

  const subjectFilter = document.getElementById('subject-filter');
  const filterSelect = document.getElementById('difficulty-filter');

  subjectFilter.addEventListener('change', fetchDoubts);
  filterSelect.addEventListener('change', fetchDoubts);
  fetchDoubts();
};

async function fetchDoubts() {
  const subjectSelect = document.getElementById('subject-filter');
  const difficultySelect = document.getElementById('difficulty-filter');
  const listContainer = document.getElementById('solver-list');

  const subject = subjectSelect.value;
  const difficulty = difficultySelect.value;

  let url = API_BASE + '/doubts';
  const params = new URLSearchParams();
  if (subject) params.append('subject', subject);
  if (difficulty) params.append('difficulty', difficulty);

  if (params.toString()) {
    url += '?' + params.toString();
  }

  try {
    const res = await fetch(url);
    const data = await res.json();

    if (!res.ok) {
      console.error('Fetch doubts error:', data);
      listContainer.innerHTML = '<div class="empty-state">Failed to load doubts.</div>';
      return;
    }

    renderDoubts(data);
  } catch (err) {
    console.error('Fetch doubts error:', err);
    listContainer.innerHTML = '<div class="empty-state">Could not connect to server.</div>';
  }
}

function renderDoubts(doubts) {
  const listContainer = document.getElementById('solver-list');


  listContainer.innerHTML = '';

  if (!doubts.length) {
    listContainer.innerHTML = '<div class="empty-state">No doubts available for the selected filters. Be the first to ask!</div>';
    return;
  }

  doubts.forEach(d => {
    const box = document.createElement('div');
    box.className = 'doubt-box';

    const badge = { easy: '🟢 Easy', medium: '🟡 Medium', hard: '🔴 Hard' }[d.difficulty] || d.difficulty;
    box.innerHTML = `
      <div style="font-weight:600">${d.question}</div>
      <div style="font-size:0.8rem;margin-top:4px;display:flex;gap:10px;opacity:0.75">
        <span>${badge}</span>
        <span>📚 ${d.subject || d.subjectName}</span>
        <span>💬 ${d.answer_count || 0} answer(s)</span>
      </div>`;
    box.onclick = function () {
      // Store ID purely for navigation to the next page
      sessionStorage.setItem('pds_currentDoubtId', d.id);
      window.location.href = 'doubtSolver2.html';
    };
    listContainer.appendChild(box);
  });
}
