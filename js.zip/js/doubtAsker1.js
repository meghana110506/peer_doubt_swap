
async function postDoubt() {
  const subjectSelect = document.getElementById('subject-select');
  const questionInput = document.getElementById('user-input');
  const difficultySelect = document.getElementById('difficulty-select');

  const subject = subjectSelect.value;
  const question = questionInput.value;
  const difficulty = difficultySelect.value;

  // Client-side validation
  const trimmed = question.trim();
  if (subject === '') { alert('Please select a subject.'); return; }
  if (trimmed === '') { alert('Please type a question before posting.'); return; }
  if (trimmed.length < 10) { alert('Question must be at least 10 characters.'); return; }
  if (trimmed.length > 1000) { alert('Question is too long (max 1000 chars).'); return; }
  if (!/[a-zA-Z]/.test(trimmed)) { alert('Question must contain text.'); return; }
  if (difficulty === '') { alert('Please select a difficulty level.'); return; }

  // Post to backend API
  try {
    const res = await fetch(API_BASE + '/doubts', {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({
        subject,
        difficulty,
        question: trimmed
      })
    });

    if (!res.ok) {
      const data = await res.json();
      alert('Error: ' + (data.error || 'Failed to post doubt.'));
      return;
    }

    // Show inline success message
    const successMsg = document.getElementById('post-success');
    successMsg.style.display = 'block';
    setTimeout(() => { successMsg.style.display = 'none'; }, 3000);
  } catch (err) {
    console.error('Error posting doubt:', err);
    alert('Could not connect to server.');
  }

  questionInput.value = '';
  difficultySelect.value = '';
  subjectSelect.value = '';
}
